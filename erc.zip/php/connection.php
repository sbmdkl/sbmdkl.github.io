<?php

 $connection = mysqli_connect("localhost","root","","discussion");
   if(!$connection) {
       echo "failed";
   }  

?>