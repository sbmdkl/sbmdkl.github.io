
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Discussion</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/sidebar.css">
    <link rel="stylesheet" href="css/section.css">
</head>
<body>
  <div id="container">
   <div id="nav">
     <ul>
         <li><a href="#">Home</a></li>
         <li><a href="#">Library</a></li>
         <li><a href="../../erc/login/login.php">Discussion</a></li>
         <li style="float:right; padding:0px;"><a href="../../erc/signup/signup.php">Sign up</a></li>
         <li style="float:right; padding:0px;"><a href="../../erc/login/login.php">Login</a></li>
     </ul>  
   </div> 